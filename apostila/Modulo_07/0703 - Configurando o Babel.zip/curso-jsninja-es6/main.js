class Teste {
  digaOla() {
    alert("Olá tudo bem!?");
  }

  digaOi() {
    alert("Oi");
  }
}
