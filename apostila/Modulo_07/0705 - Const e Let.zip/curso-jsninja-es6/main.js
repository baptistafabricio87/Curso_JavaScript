// const nunca muda
// let pode ser alterado

function digaOla(nome) {
  console.log("Olá ", nome);
}

digaOla("Felipe");
digaOla("Daniel");
