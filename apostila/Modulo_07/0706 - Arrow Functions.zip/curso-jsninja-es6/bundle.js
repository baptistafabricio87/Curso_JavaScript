"use strict";

// var soma = function(x, y) {
//   return x + y;
// };
var soma = function soma(x, y) {
  return x + y;
};

var mult = function mult(x) {
  return x * 2;
};

console.log(mult(2));
