// var soma = function(x, y) {
//   return x + y;
// };

var soma = (x, y) => x + y;
var mult = x => x * 2;

console.log(mult(2));
